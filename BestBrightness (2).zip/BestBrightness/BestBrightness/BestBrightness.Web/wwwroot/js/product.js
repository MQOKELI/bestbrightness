var dataTable;

$(document).ready(function () {
    loadDataTable();

    $('#btnGeneratePDF').click(function () {
        generatePDF();
    });
});

function loadDataTable() {
    dataTable = $('#tblData').DataTable({
        "ajax": { url: '/Product/GetAll' },
        "columns": [
            { data: 'name', "width": "25%" },
            { data: 'originalquantity', "width": "15%" },
            { data: 'remainingquantity', "width": "10%" },
            {
                data: 'pecantageOfRemainingQuantity',
                "render": function (data) {
                    return data + '%';
                },
                "width": "10%"
            },
            {
                data: 'id',
                "render": function (data) {
                    return `<div class="w-75 btn-group" role="group">
                     <a href="/product/update?id=${data}" class="btn bg-primary mx-2"> <i class="bi bi-pencil-square"></i> Restock</a>
                     <a onClick=Delete('/product/delete/${data}') class="btn bg-primary mx-2"> <i class="bi bi-trash-fill"></i> Remove</a>
                    </div>`;
                },
                "width": "25%"
            }
        ]
    });
}

function Delete(url) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function (data) {
                    dataTable.ajax.reload();
                    toastr.success(data.message);
                },
                error: function (xhr, status, error) {
                    toastr.error('An error occurred while deleting the product.');
                }
            });
        }
    });
}

function generatePDF() {
    var { jsPDF } = window.jspdf;
    var doc = new jsPDF();

    var productData = dataTable.rows({ search: 'applied' }).data().toArray();

    var col = ["Product Name", "Original Quantity", "Remaining Quantity", "Percentage of Remaining Quantity"];
    var rows = [];

    for (var i = 0; i < productData.length; i++) {
        var product = productData[i];
        var temp = [
            product.name,
            product.originalquantity,
            product.remainingquantity,
            product.pecantageOfRemainingQuantity + '%'
        ];
        rows.push(temp);
    }

    doc.autoTable(col, rows);

    doc.save('ProductData.pdf');
}
