﻿using BestBrightness.Application.Common.Interfaces;
using BestBrightness.Domain.Entities;
using BestBrightness.Infrastrcture.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BestBrightness.Infrastrcture.Repository
{
    internal class SalesRepository : Repository<Sale>, ISalesRepository
    {
        private readonly ApplicationDbContext _db;

        public SalesRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }
        public void Update(Sale entity)
        {
            _db.Sales.Update(entity);
        }
    }
}
