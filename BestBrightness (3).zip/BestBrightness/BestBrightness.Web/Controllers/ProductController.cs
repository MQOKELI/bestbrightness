﻿using BestBrightness.Application.Common.Interfaces;
using BestBrightness.Application.Common.Utility;
using BestBrightness.Application.Services.Interfaces;
using BestBrightness.Domain.Entities;
using BestBrightness.Infrastrcture.Migrations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BestBrightness.Web.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
       

        public ProductController(IProductService villaService)
        {
            _productService = villaService;
        }
        [Authorize]
        public IActionResult Index()
        {
            var products = _productService.GetAllProducts();
            return View(products);
        }
        [Authorize(Roles = SD.Role_Admin)]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = SD.Role_Admin)]
        public IActionResult Create(Product obj)
        {

            obj.Remainingquantity = obj.Originalquantity;
            if (ModelState.IsValid)
            {

                _productService.CreateProduct(obj);
                TempData["success"] = "The Product has been created successfully.";
                return RedirectToAction(nameof(Index));
            }
            return View();

        }

        [Authorize(Roles = SD.Role_Admin)]
        public IActionResult update(int id)
        {
            
               
               var product = _productService.GetProductById(id);
               return View(product);
                     
        }

        [HttpPost]
        [Authorize(Roles = SD.Role_Admin)]
        public IActionResult update(Product product)
        {
            if (ModelState.IsValid)
            {
                var original = _productService.GetProductById(product.Id);
                product.Remainingquantity = original.Remainingquantity +  product.Remainingquantity;
                product.Originalquantity = product.Remainingquantity;
                _productService.UpdateProduct(product);
                TempData["success"] = "product restocked successfully";
                return RedirectToAction("Index");
            }
            else
            {
                return View(product);
            }
        }

        #region API Calls
        [HttpGet]
        [Authorize]
        public IActionResult GetAll()
        {
            IEnumerable<Product> objProducts;
            objProducts = _productService.GetAllProducts();

            return Json(new { data = objProducts });
        }
        [HttpDelete]
        [Authorize(Roles = SD.Role_Admin)]
        public IActionResult Delete(int id)
        {
            try
            {
                var isDeleted = _productService.DeleteProduct(id);
                if (isDeleted)
                {
                    return Json(new { success = true, message = "Product deleted successfully." });
                }
                else
                {
                    return Json(new { success = false, message = "Product not found." });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"An error occurred: {ex.Message}" });
            }
        }

        #endregion


    }
}
