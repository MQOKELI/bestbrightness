﻿using bestbrightness.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace bestbrightness.Services
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions options):base(options)
        {
            
        }
        public DbSet<Products> Products { get; set; }
        
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            var admin = new IdentityRole
            {
                Id = Guid.NewGuid().ToString(),
                Name = "admin",
                NormalizedName = "ADMIN"
            };

            var salesperson = new IdentityRole
            {
                Id = Guid.NewGuid().ToString(),
                Name = "salesperson",
                NormalizedName = "SALESPERSON"
            };

            builder.Entity<IdentityRole>().HasData(admin, salesperson);
        }

    }
}
