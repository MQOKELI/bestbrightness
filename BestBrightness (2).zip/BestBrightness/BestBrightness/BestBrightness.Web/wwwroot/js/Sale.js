var dataTable;

$(document).ready(function () {
    loadDataTable();

    $('#btnGeneratePDF').click(function () {
        generatePDF();
    });
});

function loadDataTable() {
    dataTable = $('#tblData').DataTable({
        "ajax": { url: '/Sales/GetAll' },
        "columns": [
            { data: 'product.name', "width": "20%" },
            { data: 'quantitySold', "width": "10%" },
            { data: 'totalPrice', "width": "10%" },
            {
                data: 'dateSold',
                "render": function (data) {
                    return new Date(data).toLocaleDateString();
                },
                "width": "15%"
            },
            { data: 'user.name', "width": "15%" },
            { data: 'user.email', "width": "20%" },
            {
                data: 'id',
                "render": function (data) {
                    return `<div class="w-75 btn-group" role="group">
                     <a onClick=Delete('/Sales/Delete/${data}') class="btn btn-primary mx-2"> <i class="bi bi-trash-fill"></i> Delete</a>
                    </div>`
                },
                "width": "10%"
            }
        ]
    });
}

function Delete(url) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function (data) {
                    dataTable.ajax.reload();
                    toastr.success(data.message);
                },
                error: function (xhr, status, error) {
                    toastr.error('An error occurred while deleting the sale.');
                }
            })
        }
    })
}

function generatePDF() {
    var { jsPDF } = window.jspdf;
    var doc = new jsPDF();

    var salesData = dataTable.rows({ search: 'applied' }).data().toArray();

    var col = ["Product Name", "Quantity Sold", "Total Price", "Date Sold", "Sales Person", "Email"];
    var rows = [];

    for (var i = 0; i < salesData.length; i++) {
        var sale = salesData[i];
        var temp = [
            sale.product.name,
            sale.quantitySold,
            sale.totalPrice,
            new Date(sale.dateSold).toLocaleDateString(),
            sale.user.name,
            sale.user.email
        ];
        rows.push(temp);
    }

    doc.autoTable(col, rows);

    doc.save('SalesData.pdf');
}
