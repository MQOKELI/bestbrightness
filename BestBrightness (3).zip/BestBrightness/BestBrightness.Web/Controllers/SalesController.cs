﻿using BestBrightness.Application.Services.Implementation;
using BestBrightness.Application.Services.Interfaces;
using BestBrightness.Domain.Entities;
using BestBrightness.Domain.ViewModels;
using BestBrightness.Infrastrcture.Migrations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Security.Claims;
using System.Security.Cryptography;

namespace BestBrightness.Web.Controllers
{
    public class SalesController : Controller
    {
        private readonly ISalesService _salesService;
        private readonly IProductService _productService;

        public SalesController(ISalesService salesService, IProductService villaService)
        {
            _salesService = salesService;
            _productService = villaService;
        }
        public IActionResult Index()
        {
            var sales = _salesService.GetAllSales();
            return View(sales);
        }

        [Authorize]
        public IActionResult Create()
        {
            SaleVM salesMV = new()
            {
                productList = _productService.GetAllProducts().Select(u => new SelectListItem
                {
                    Text = u.Name,
                    Value = u.Id.ToString()
                })
            };
            return View(salesMV);
        }

        
        [HttpPost]
        public IActionResult Create(SaleVM salesVM)
        {
            var claimsIdentity = (ClaimsIdentity)User.Identity;
            var userId = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier).Value;

            if (salesVM.sale != null)
            {
                salesVM.sale.SalesPersonId = userId;

                
                   
                    var product = _productService.GetProductById(salesVM.sale.ProductId);
                    if(product.Remainingquantity >= salesVM.sale.QuantitySold)
                {
                    _salesService.CreateSale(salesVM.sale);
                    product.Remainingquantity -= salesVM.sale.QuantitySold;
                    _productService.UpdateProduct(product);
                    TempData["success"] = "The Sale has been added successfully.";
                    return RedirectToAction(nameof(Index));
                }
                    else
                {
                    TempData["error"] = "The Sale could not be edded";

                    salesVM.productList = _productService.GetAllProducts().Select(u => new SelectListItem
                    {
                        Text = u.Name,
                        Value = u.Id.ToString()
                    });

                    return View(salesVM);
                }
                
            }

            // Re-populate the product list in case of validation error
            salesVM.productList = _productService.GetAllProducts().Select(u => new SelectListItem
            {
                Text = u.Name,
                Value = u.Id.ToString()
            });

            return View(salesVM);
        }

        #region API Calls
        [HttpGet]

        public IActionResult GetAll()
        {
            IEnumerable<Sale> objSales;
            objSales = _salesService.GetAllSales();
            return Json(new { data = objSales });
        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                var isDeleted = _salesService.DeleteSale(id);
                if (isDeleted)
                {
                    return Json(new { success = true, message = "sale deleted successfully." });
                }
                else
                {
                    return Json(new { success = false, message = "sale not found." });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"An error occurred: {ex.Message}" });
            }
        }

        #endregion
    }
}
