var dataTable;

$(document).ready(function () {
    loadDataTable();

    $('#btnGeneratePDF').click(function () {
        generatePDF();
    });
});

function loadDataTable() {
    dataTable = $('#tblData').DataTable({
        "ajax": { url: '/Account/GetAll' },
        "columns": [
            { data: 'name', "width": "25%" },
            { data: 'email', "width": "25%" },
            { data: 'phoneNumber', "width": "20%" },
            
            {
                data: 'id',
                "render": function (data) {
                    return `<div class="w-75 btn-group" role="group">
                     
                     <a onClick=Delete('/user/delete/${data}') class="btn bg-black mx-2"> <i class="bi bi-trash-fill"></i> Delete</a>
                    </div>`;
                },
                "width": "20%"
            }
        ]
    });
}

function Delete(url) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function (data) {
                    dataTable.ajax.reload();
                    toastr.success(data.message);
                },
                error: function (xhr, status, error) {
                    toastr.error('An error occurred while deleting the user.');
                }
            });
        }
    });
}

function generatePDF() {
    var { jsPDF } = window.jspdf;
    var doc = new jsPDF();

    var userData = dataTable.rows({ search: 'applied' }).data().toArray();

    var col = ["Name", "Email", "Phone Number", "Role"];
    var rows = [];

    for (var i = 0; i < userData.length; i++) {
        var user = userData[i];
        var temp = [
            user.name,
            user.email,
            user.phoneNumber || '',
            user.role
        ];
        rows.push(temp);
    }

    doc.autoTable(col, rows);

    doc.save('UserData.pdf');
}
