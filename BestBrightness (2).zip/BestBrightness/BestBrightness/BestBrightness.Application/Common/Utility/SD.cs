﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BestBrightness.Application.Common.Utility
{
    public static class SD
    {
        public const string Role_SalesPerson = "SalesPerson";
        public const string Role_Admin = "Admin";
    }
}
